document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const menuToggle = document.getElementById('menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (menuToggle && mobileMenu) {
        menuToggle.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }
    
    // Quote toggle
    const quoteBtn = document.getElementById('quote-btn');
    const quote = document.getElementById('quote');
    
    if (quoteBtn && quote) {
        quoteBtn.addEventListener('click', function() {
            quote.classList.toggle('hidden');
            quoteBtn.textContent = quote.classList.contains('hidden') ? 'Ver Citação de Guattari' : 'Ocultar Citação';
        });
    }
    
    // Cosmovision modal
    const cosmovisionBtn = document.getElementById('cosmovision-btn');
    const cosmovisionModal = document.getElementById('cosmovision-modal');
    const closeCosmovision = document.getElementById('close-cosmovision');
    
    if (cosmovisionBtn && cosmovisionModal) {
        cosmovisionBtn.addEventListener('click', function() {
            cosmovisionModal.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        });
        
        closeCosmovision.addEventListener('click', function() {
            cosmovisionModal.classList.add('hidden');
            document.body.style.overflow = 'auto';
        });
        
        cosmovisionModal.addEventListener('click', function(e) {
            if (e.target === cosmovisionModal) {
                cosmovisionModal.classList.add('hidden');
                document.body.style.overflow = 'auto';
            }
        });
    }
    
    // Example modals
    const exampleBtns = document.querySelectorAll('.example-btn');
    const exampleModal = document.getElementById('example-modal');
    const exampleTitle = document.getElementById('example-title');
    const exampleContent = document.getElementById('example-content');
    const closeExample = document.getElementById('close-example');
    
    const examples = {
        climate: {
            title: "Mudanças Climáticas",
            content: `
                <p class="mb-4">As mudanças climáticas estão causando impactos severos em todo o mundo:</p>
                <ul class="list-disc pl-6 mb-4 space-y-2">
                    <li>Aumento da temperatura média global em 1.1°C desde a era pré-industrial</li>
                    <li>Derretimento acelerado das calotas polares e geleiras</li>
                    <li>Aumento do nível do mar em 3.3 mm por ano</li>
                    <li>Eventos climáticos extremos mais frequentes e intensos</li>
                </ul>
                <p>Se não agirmos agora, podemos enfrentar um aumento de até 4°C até 2100, com consequências catastróficas.</p>
            `
        },
        pollution: {
            title: "Poluição Ambiental",
            content: `
                <p class="mb-4">A poluição afeta todos os compartimentos ambientais:</p>
                <div class="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <h4 class="font-bold text-red-600 mb-2">Poluição do Ar</h4>
                        <ul class="list-disc pl-6 space-y-1">
                            <li>9 de cada 10 pessoas respiram ar insalubre</li>
                            <li>7 milhões de mortes prematuras por ano</li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="font-bold text-red-600 mb-2">Poluição da Água</h4>
                        <ul class="list-disc pl-6 space-y-1">
                            <li>80% das águas residuais são descarregadas sem tratamento</li>
                            <li>1,8 bilhão de pessoas bebem água contaminada</li>
                        </ul>
                    </div>
                </div>
                <p>A poluição plástica nos oceanos já afeta mais de 800 espécies marinhas.</p>
            `
        },
        biodiversity: {
            title: "Perda de Biodiversidade",
            content: `
                <p class="mb-4">Estamos vivendo a sexta extinção em massa:</p>
                <ul class="list-disc pl-6 mb-4 space-y-2">
                    <li>1 milhão de espécies ameaçadas de extinção</li>
                    <li>Perda de habitat de 100 a 1000 vezes maior que a taxa natural</li>
                    <li>68% de populações de vertebrados selvagens reduzidas desde 1970</li>
                    <li>Desflorestamento de 10 milhões de hectares por ano</li>
                </ul>
                <p class="mb-4">As consequências incluem:</p>
                <ul class="list-disc pl-6 space-y-2">
                    <li>Colapso de ecossistemas</li>
                    <li>Perda de serviços ecossistêmicos</li>
                    <li>Risco à segurança alimentar</li>
                    <li>Impactos na saúde humana</li>
                </ul>
            `
        }
    };
    
    exampleBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const exampleKey = this.getAttribute('data-example');
            const example = examples[exampleKey];
            
            if (example) {
                exampleTitle.textContent = example.title;
                exampleContent.innerHTML = example.content;
                exampleModal.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }
        });
    });
    
    if (closeExample && exampleModal) {
        closeExample.addEventListener('click', function() {
            exampleModal.classList.add('hidden');
            document.body.style.overflow = 'auto';
        });
        
        exampleModal.addEventListener('click', function(e) {
            if (e.target === exampleModal) {
                exampleModal.classList.add('hidden');
                document.body.style.overflow = 'auto';
            }
        });
    }
    
    // Back to top button
    const backToTopBtn = document.getElementById('back-to-top');
    
    if (backToTopBtn) {
        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
    
    // Scroll animations
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Observe sections
    document.querySelectorAll('section').forEach(section => {
        observer.observe(section);
    });
    
    // Observe cards
    document.querySelectorAll('.flip-card, .bg-white, .bg-gray-50').forEach(card => {
        observer.observe(card);
    });
});